# Code written by Tomás Vélez Acosta, 20/03/2022
import numpy as np
from matplotlib import pyplot as plt


dom = 3.6 # Width of the visualization window, splited symetrically
signal_size = 350 # Number of discretizations in domain
dt = dom / signal_size # Equal spacing in the domain

'''
To use this code, change Fst for the corresponding string of the desired static function
and Snd for the corresponding string of the desired convolution kernel. (see conv for more information)
'Rectangle' 'Triangle' 'Delta
'''
Fst = 'Triangle'
Snd = 'Rectangle'

def rect(width,center,Amplitude):
    f0 = np.array([Amplitude if ((n*dt - dom/2)<= (center + width/2) and (n*dt - dom/2) >= (center-width/2)) else 0 for n in range(signal_size)]) 
    return f0

def tri(begining,ending):
    f0 = np.array([(((n*dt-dom/2)-begining)/(ending-begining)) if ((n*dt-dom/2)>begining and (n*dt-dom/2)<ending) else 0 for n in range(signal_size)])
    return f0

def conv(Principal , Secondary):
    '''
    # Function to visualize the convolution of two desired functions
    # Inputs:
    Principal - String to choose the static function

    Secondary - String to choose the convolution kenrel

    # The choices for the strings are:
    'Delta' - For a delta function

    'Triangle' - For triangle function
    
    'Rectangle' - For rectangle function
    '''
    t = np.linspace(-dom/2,dom/2,signal_size)
    out = np.zeros(signal_size)

    if Principal == 'Triangle':
        Main = tri(-0.5,0.5)
    elif Principal == 'Rectangle':
        Main = rect(1,0,1)
    elif Principal == 'Delta':
        Main = rect(dt,0,1/dt)

    fig,ax=plt.subplots()
    for i in range(signal_size):
        timing = 0.001
        if Secondary == 'Triangle':
            Second = tri((-dom/2+i*dt),((-dom/2+1+i*dt)))
        elif Secondary == 'Rectangle':
            Second = rect(1,(-dom/2)+i*dt,1)
        elif Secondary == 'Delta':
            Second = rect(dt,(-dom/2)+i*dt,1/dt)
        last = np.multiply(Main,Second)
        DY=np.sum(last)
        out[i] = DY*dt
        temp = t[0:i+1]
        ax.cla()
        ax.plot( t , Main , 'c-',t , Second ,'r--',temp ,out[0:i+1],'g-.')
        ax.set_ylim(-0.01,1.1)
        ax.set_title('Convolution of '+Secondary+' over '+Principal)
        plt.pause(timing)
        

conv(Fst,Snd)






