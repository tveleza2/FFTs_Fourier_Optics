# Code written by Tomás Vélez Acosta, 20/03/2022
from cmath import pi
from PIL import Image
import numpy as np
import scipy.signal as scp
import matplotlib.pyplot as plt
kernel_size = 5 # Size of Gaussian Kernel in pixels
STD = 1 # Standard deviation of the gaussian filter
def imageShow (inp, title, saving):
    '''
    # Function to display an image
    # Inputs:
    # inp - The input complex field
    # title - The title of the displayed image        
    '''
    plt.imshow(inp,cmap='gray'), plt.title(title)  # image in gray scale
    plt.show()  # show image
    if saving==True:
        plt.savefig('D:\OneDrive - Universidad EAFIT\Semestre VI\Optical Processing\FinalProject\Imagenes Finales\Green\Batch'+title+'.bmp')
    return

def gaussian_kernel(image,size,sigma,padding):
    signal_size = np.shape(image)
    if padding==True:
        f0 = np.zeros(signal_size,dtype=float)
    elif padding ==False:
        f0 = np.zeros((size,size),dtype=float)

    
    for i in range(size):
        for j in range (size):
            if padding==True:
                f0[int((signal_size[0] - size)/2) + i ,int((signal_size[1] - size)/2)+j]=255*np.exp(-((i-int(size/2))**2 + (j-int(size/2))**2)/(2*sigma**2))
            elif padding ==False:
                f0[i,j] = np.exp(-((i-int(size/2))**2 + (j-int(size/2))**2)/(2*sigma**2))/(2*pi*sigma**2)

    return f0

def intensity (inp, log):
    '''
    # Function to calcule the intensity representation of a given complex field
    # Inputs:
    # inp - The input complex field
    # log - boolean variable to determine if a log representation is applied
    '''
    out = np.abs(inp)
    out = out*out
    if log == True:
        out = 20 * np.log(out)
    out = out - np.amin(out)
    out = out / np.amax(out)
    out = np.uint8(out*255)
    return out

img = Image.open("dementor.jpg")
npimg = np.array(img)


# Filtering via convolution
gauss = gaussian_kernel(npimg,kernel_size,STD,False)
filtered = scp.convolve2d(npimg,gauss)
filtered = filtered[2:425,2:542]

# Filtering via Fourier Transform
FTimg = np.fft.fftshift(np.fft.fft2(np.fft.fftshift(npimg)))
gaussker = np.fft.fftshift(np.fft.fft2(np.fft.fftshift(gaussian_kernel(npimg,kernel_size,STD,True))))
FTfilt = FTimg*gaussker
filt = np.fft.ifftshift(np.fft.ifft2(np.fft.ifftshift(FTfilt)))
filt = np.real(filt)


#PLotting
fig,axs = plt.subplots(2,2)
axs[0,0].imshow(npimg,cmap='gray'),axs[0,0].set_title('Original Image')
axs[0,1].imshow(filtered,cmap='gray'),axs[0,1].set_title('Convolution')
axs[1,0].imshow(filt,cmap='gray'),axs[1,0].set_title('Fourier')

dif = filtered-filt
axs[1,1].imshow(dif),axs[1,1].set_title('Difference')
plt.show()