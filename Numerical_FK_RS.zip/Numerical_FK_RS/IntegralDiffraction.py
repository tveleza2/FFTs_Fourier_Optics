'''
Code developed by Tomás Vélez Acosta
'''

from math import pi
import numpy as np
import math as mt
from matplotlib import pyplot as plt


def rect2D(size, width_x, width_y, center=None):
    '''
    Make a 2D rect function.
    Size is the length of the signal
    width is width of the rect function
    '''
    if center is None:
        x0 = y0 = size // 2
    else:
        x0 = center[0]
        y0 = center[1]

    data = np.zeros((size,size))
    data[int(x0-width_x/2):int(x0+width_x/2), int(y0-width_y/2):int(y0+width_y/2)] = 1

    return data

def circ2D(size, pradius, center=None):
    '''
    Makes a 2D circ function.
    Size is the length of the signal
    pradius is the pradius of the circ function
    '''
    if center is None:
        x0 = y0 = size // 2
    else:
        x0 = center[0]
        y0 = center[1]

    data = np.zeros((size,size),dtype='complex_')
    for j in range (size):
        for i in range (size):
            if np.power(j-x0, 2) + np.power(i-y0, 2) < np.power(pradius, 2):
                data[i,j] = 1
    return data

def imageShow (inp, title):
    '''
    # Function to display an image
    # Inputs:
    # inp - The input complex field
    # title - The title of the displayed image        
    '''
    plt.imshow(inp, cmap='gray'), plt.title(title)  # image in gray scale
    plt.show()  # show image

    return

def amplitude (inp, log):
    '''
    # Function to calcule the amplitude representation of a given complex field
    # Inputs:
    # inp - The input complex field
    # log - boolean variable to determine if a log representation is applied    
    '''
    out = np.abs(inp)
    if log == True:
        out = 20 * np.log(out)
    return out

def intensity (inp, log):
    out1 = amplitude(inp,False)
    out = out1*out1
    if log == True:
        out = 20 * np.log(out)
    return out

def prop_sol(Propagator, A, wavelength,r21,mr21,r01,mr01):
    '''
    # Function to choose the diffraction solution to use within the algorithm
    # Inputs:
    Propagator - 'K' Kirchoff integral diffraction formula; 'RS1','RS2' Raleygh Sommerfeld diffraction formulas 1 and 2

    A - Amplitude of the wave

    Wavelength - Wavelength of the light source
    
    r21 - Location vector from source to apperture
    
    mr21 - Magnitude of r21
    
    r01 - Location vector from viewing point to apperture
    
    mr01 - Magnitude of r01
    '''
    f0 = (A/(1j*wavelength))*(np.exp((mr21)*1j*k)/(mr21))
    if Propagator == 'K':
        f0 = f0*((r01[2]/mr01)-(r21[2]/mr21))/2
    elif Propagator == 'RS1':
        f0 = f0*(r01[2]/mr01)
    elif Propagator == 'RS2':
        f0 = f0*(-r21[2]/mr21)
    return f0

#Simulation Control variables

Propagator = 'RS2' # Expresion to choose the desired diffraction solution, go to prop_sol for more information
signal_size = 32 # Size of visualization
dx = dy = 0.08/signal_size #Pixel Size
M = N = signal_size # Control of the size of the matrices

x_center = signal_size/2# Optical...
y_center = signal_size/2# ...axis of the system
radius = 0.02 # Radius of the aperture in meters
Pradius = int(radius/dx) #Radius of the aperture in pixels


# Light source
wavelength = 0.6328/(1000000) # Wavelength of the illumination Source
k = 2*pi/wavelength # Wave number of the ilumination source
A = 1 # Wave amplitude of the source



z=-10000 # Z Component of the coordinates from the Source
SourceZ = np.array([0,0,z]) # Coordinates of the source
ScreenZ = 500 # Z Component of the observation screen coordinates
SigmaZ = 0 # Z Component of the aperture coordinates


# Aperture defines the geometry of the apperture, for circular apperture use circ2D, for rectangular apperture use rect2D

Aperture = circ2D(signal_size,Pradius,center=None)
# Aperture = rect2D(signal_size,10,10,center=None)


imageShow(amplitude(Aperture,'False'),'Aperture')
U0 = np.zeros((signal_size,signal_size),dtype='complex_')


# The first pair of loops ranges over the points in the viewing screen in order to determine r01
for a in range(signal_size):
    for b in range(signal_size):
        ViewPC = np.array([(a-x_center)*dx,-(b-y_center)*dy,ScreenZ]) # Coordinates of the point in the viewing scree 
        U1=np.zeros((signal_size,signal_size),dtype='complex_')
        # The second pair of loops ranges over the points in the apperture to determine r21
        for i in range(signal_size):
            for j in range(signal_size):                
                LocalC=np.array([(i-signal_size/2)*dx,-(j-signal_size/2)*dy,SigmaZ])#Coordinates of the point in the apperture

                r21 = LocalC - SourceZ
                mr21 = mt.sqrt(r21[0]**2 + r21[1]**2 + r21[2]**2)

                r01 = LocalC - ViewPC
                mr01 = mt.sqrt(r01[0]**2 + r01[1]**2 + r01[2]**2)

                '''By knowing the geometrical parameters of the system, the following two lines compute weight of
                each point source in the apperture to form the diffraction pattern. It's important to take into 
                account that only the points within the apperture give a non zero aportation to the pattern, hence
                it's mandatory to multiply the field expression by the apperture.
                '''
                U1[i,j] = Aperture[i,j] * prop_sol(Propagator, A, wavelength,r21,mr21,r01,mr01)
                U0[a,b] = U0[a,b] + (dx**2) * U1[i,j]*np.exp(mr01*1j*k)/mr01

# Finally, the code plots the amplitude of the diffraction pattern
imageShow(intensity(U0,False),('Diffraction Pattern \n Screen-Aperture distance = '+str(ScreenZ)+' m \n Aperture radius = ' +str(radius*1000) + ' mm' ))


          
