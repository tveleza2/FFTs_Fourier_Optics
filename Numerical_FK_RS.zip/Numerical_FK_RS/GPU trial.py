from numba import cuda,jit
import numpy as np
# to measure exec time
from timeit import default_timer as timer   

#%%

grid_size = 2
block_size = 256

# normal function to run on cpu
def cudakernel0(array):
    for i in range(array.size):
        array[i] += 0.5
  
# function optimized to run on gpu 
@cuda.jit()                         
def cudakernel1(array):
    for i in range(array.size):
        array[i] += 0.5
#%%
n = 10000000                         
a = np.ones(n, dtype = np.float64)
  #%%
start = timer()
cudakernel0(a)
print("without GPU:", timer()-start)    
  #%%
start = timer()
cudakernel1[grid_size,block_size](a)
print("with GPU:", timer()-start)
